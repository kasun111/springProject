package com.sadeepa.em.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sadeepa.em.model.Activity;

@Controller
public class ActivityController {

	@RequestMapping(value="/greeting")
	public String getWelcomeMessage(Model model){
		
		String abc = "<h1> Welcome to spring MVC </h1><br>Okay working";
		model.addAttribute("greetingMsg",abc);
		model.addAttribute("r8works","from the other attribute");
		return "welcome";
	} 
	@RequestMapping(value="/addactivity")
	public String addActivity(@ModelAttribute("activities")Activity activity){
		
		System.out.println("Activity is ="+activity.getActivityName());
		//System.out.println("Activity Code is ="+activity.getActivityCode());
		if(activity.getActivityName()==null){
			return "addActivity";
		}else{
			return "redirect:addSubActivity.html";
		}
	}
	@RequestMapping(value="/addSubActivity")
	public String addSubActivity(@ModelAttribute("activities")Activity activity){
		System.out.println("Sub Activity name is :"+ activity.getActivityName());
		return "addActivity";
	}
}
