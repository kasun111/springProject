package com.siraj.hms;

public enum BetianHouses {
	CLAUDE,LUKE,CASSIAN,CAMMILUS

}
