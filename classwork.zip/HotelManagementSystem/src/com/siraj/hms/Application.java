package com.siraj.hms;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siraj.hms.model.Food;
import com.siraj.hms.service.FoodService;
import com.siraj.hms.service.FoodServiceImpl;

public class Application {
	public static void main(String[] args) {
//		FoodService foodService = new FoodServiceImpl();
//		List<Food> foods = foodService.getAllFoods();
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		FoodService foodService = applicationContext.getBean("foodService",FoodService.class);
		List<Food> foods = foodService.getAllFoods();
		
		for (Food food : foods) {
			System.out.println("Food is :"+food.getName()+" and type is : "+food.getType());
		}
	}
}
