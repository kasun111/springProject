package com.siraj.hms.repository;

import java.util.List;

import com.siraj.hms.model.Food;

public interface FoodRepository {
	public List<Food>getAllFoods();
}
