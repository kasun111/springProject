package com.siraj.hms.repository;

import java.util.ArrayList;
import java.util.List;

import com.siraj.hms.model.Food;

public class FoodRepositoryImpl implements FoodRepository{

	@Override
	public List<Food>getAllFoods(){
		
		List<Food> foods = new ArrayList<>();
		Food food = new Food();
		food.setName("Biriyani");
		food.setType("High-Food");
		foods.add(food);
		return foods;
	}
	

}
