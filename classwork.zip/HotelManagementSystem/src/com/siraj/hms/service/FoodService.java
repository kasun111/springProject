package com.siraj.hms.service;

import java.util.List;

import com.siraj.hms.model.Food;

public interface FoodService {
	public List<Food>getAllFoods();
}
