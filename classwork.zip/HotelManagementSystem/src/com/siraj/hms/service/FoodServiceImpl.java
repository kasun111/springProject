package com.siraj.hms.service;

import java.util.List;

import com.siraj.hms.model.Food;
import com.siraj.hms.repository.FoodRepository;

public class FoodServiceImpl implements FoodService {
	private FoodRepository foodRepository;

	public FoodRepository getFoodRepository() {
		return foodRepository;
	}

	public void setFoodRepository(FoodRepository foodRepository) {
		this.foodRepository = foodRepository;
	}

	@Override
	public List<Food> getAllFoods() {
		System.out.println("on food serve imp");
		return foodRepository.getAllFoods();
	}
	
	
	
	
}
